

export default function Admin() {


  return (
    <>
      <h1>Admin  proof</h1>
    </>
  );
}
