import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Home from "../pages/Home/home";
import Login from "../pages/Login/login";
import Register from "../pages/Register/register";
import ProtectedRoute from "./ProtectedRoute";
import RoleProtectedRoute from "./RoleProtectedRoute";
import Layout from "../components/Layout/Layout";
import Profile from "../pages/Profile/Profile";
import AdminDashboard from "../pages/Dashboard/AdminDashboard/AdminDashboard";
import UserDashboard from "../pages/Dashboard/UserDashboard/UserDashboard"; // por si lo tienes
import Unauthorized from "../pages/Unauthorized/Unauthorized";

export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>

        {/* PÚBLICAS */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* PROTEGIDAS */}
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          {/* ADMIN */}
          <Route
            path="/dashboard/admin"
            element={
              <RoleProtectedRoute role="Admin">
                <AdminDashboard />
              </RoleProtectedRoute>
            }
          />

          {/* USER */}
          <Route
            path="/dashboard/user"
            element={
              <RoleProtectedRoute role="User">
                <UserDashboard />
              </RoleProtectedRoute>
            }
          />

          {/* PERFIL (cualquiera con token) */}
          <Route path="/profile" element={<Profile />} />
        </Route>

        {/* ACCESO DENEGADO */}
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* 404 */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
