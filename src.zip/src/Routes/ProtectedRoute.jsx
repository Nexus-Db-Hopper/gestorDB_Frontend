import { Navigate } from "react-router-dom";

export default function RoleProtectedRoute({ children, role }) {
  const token = localStorage.getItem("token");
  const userRole = localStorage.getItem("role");

  if (!token) return <Navigate to="/login" replace />;

  return userRole === role ? children : <Navigate to="/unauthorized" replace />;
}
